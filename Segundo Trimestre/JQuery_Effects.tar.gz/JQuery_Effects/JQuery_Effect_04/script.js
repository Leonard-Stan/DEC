$(function () {
    $("h1").click(function () {
        $(this).animate({ color: "red" }, 1000);
    });
});