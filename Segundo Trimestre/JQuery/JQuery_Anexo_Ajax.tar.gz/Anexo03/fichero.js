
document.write("hola mundo")