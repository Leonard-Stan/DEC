<?php


sleep(5);

$hora_actual = date('H:i:s');
echo "La hora actual es: $hora_actual\n";
?>
