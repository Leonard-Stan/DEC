$(document).ready(function(){

    const imgagen = $("img");


    $("#1").click(function(){

        imgagen.show(1000);
    
        })

    $("#2").click(function(){

    imgagen.hide("slow");

    })

})
